<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${KEBAB_CASE_NAME}"
}
</script>

<style lang="scss" scoped>

</style>


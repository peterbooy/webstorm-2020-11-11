import React, {Component, useState} from "react";

const Hello:React.FC<{}> = (props)=>{
    const [count, setCount] = useState<number>(0)
        return(
        <div>
            AABBCC
        </div>
        )
    }
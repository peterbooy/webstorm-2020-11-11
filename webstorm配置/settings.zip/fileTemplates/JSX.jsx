import React, {Component} from "react";

class S extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default S;
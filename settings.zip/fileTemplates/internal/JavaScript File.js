document.ondragstart = function () {
    return false;
};